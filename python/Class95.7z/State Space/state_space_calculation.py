import math

##from read_data import *
##from random_table import *
##
##def stirling(n, k):
##    output = 0
##    for j in range(k + 1):
##        factor = (-1)**(k-j)
##        output += factor*choose(k, j)*j**n
##    return output/float(math.factorial(k))
##
##def choose(n, m):
##    output = math.factorial(n)
##    output = output/float(math.factorial(m)*math.factorial(n-m))
##    return output
##
##def bell(n, l):
##    output = 0
##    for k in range(l + 1):
##        output += stirling(n, k)
##    return output
##        
##
##
##possibilities = 0    
##for course in courses.values():
##    
##    n = len(course.registrants)
##    k = course.no_groups
##
##    if k == 0:
##        continue
##
##    possibilities += stirling(n, k)
##    print course.name

##print possibilities
print 25.**129
print 7.**129

##
##print bell(129, 25)
##print bell(129, 7)
