from random_table import *

test = random_table()
print test
