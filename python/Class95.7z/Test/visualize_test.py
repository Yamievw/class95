from random_table import *
from HC_hill_climber import *


schedule = random_table()
schedule.plot()
#schedule.plot_course("Compilerbouw")
#schedule.personal("13284244", True)


#schedule = hill_climber_activities(schedule, 30)

#schedule.plot()
